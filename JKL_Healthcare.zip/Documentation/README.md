# JKL Healthcare System
## Overview
This project is a prototype for a secure healthcare management system, developed using ASP.NET Core.

### Features
1. User Registration and Login
2. Patient Management
3. Caregiver Assignment
4. Appointment Scheduling

### How to Run
1. Restore NuGet packages.
2. Update the database connection string in `appsettings.json`.
3. Run the project using Visual Studio or `dotnet run`.
4. Apply the database schema from `Database/setup.sql`.

### Security
- Passwords are hashed using BCrypt.
- HTTPS is enforced for all communications.
- Role-based access control is implemented.