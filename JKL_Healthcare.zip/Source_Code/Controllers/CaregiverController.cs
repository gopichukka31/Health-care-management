using Microsoft.AspNetCore.Mvc;

namespace JKLHealthcare.Controllers
{
    public class CaregiverController : Controller
    {
        public IActionResult Assign()
        {
            // Add logic for caregiver assignment
            return View();
        }

        public IActionResult Availability()
        {
            // Add logic for tracking caregiver availability
            return View();
        }
    }
}