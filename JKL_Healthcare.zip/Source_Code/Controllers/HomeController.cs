using Microsoft.AspNetCore.Mvc;

namespace JKLHealthcare.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}