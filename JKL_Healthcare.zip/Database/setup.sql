CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50) NOT NULL,
    PasswordHash NVARCHAR(255) NOT NULL,
    Role NVARCHAR(20) NOT NULL
);

CREATE TABLE Patients (
    PatientID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100),
    Address NVARCHAR(200),
    MedicalRecords NVARCHAR(MAX)
);

CREATE TABLE Caregivers (
    CaregiverID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100),
    Availability NVARCHAR(50)
);

CREATE TABLE Appointments (
    AppointmentID INT IDENTITY(1,1) PRIMARY KEY,
    PatientID INT FOREIGN KEY REFERENCES Patients(PatientID),
    CaregiverID INT FOREIGN KEY REFERENCES Caregivers(CaregiverID),
    AppointmentDate DATETIME NOT NULL
);